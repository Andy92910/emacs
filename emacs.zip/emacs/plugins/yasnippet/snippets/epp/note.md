<meta http-equiv='Content-Type' content='text/html; charset=utf-8' />

<link href="/usr/local/google/prettyprint/google-code-prettify/src/prettify.css" type="text/css" rel="stylesheet" />
<script type="text/javascript" src="/usr/local/google/prettyprint/google-code-prettify/src/prettify.js"></script>
<!-- language-all: lang-cpp -->
<body onload="prettyPrint()">
# lecture 13
***

![2 level pgae table](./pic/2 level page table.png) 

**2 level page table**

* 32 bit virtual address space. 10 for first level page table, 10 for second level, 12 for index in each page  
* called perfect square of page tables. because each entry in first level page table is 32 bit, 4 byte. in total 1024 entries, so first level page table size is 4k byte , same as page size.
* so we can page the page tables

> page table entries in level 1 and 2 are almost the same, they are all physical address  
> part of the level 2 page table could be on disk, page out the page table  
> **context switch from process A to B, just need to change the page_table_ptr, the two level page tables stay where they are**  
> _the page_table_ptr is stored in one register on each processor_  
> _the continuous address in virtual address space may not be contiguous on physical address_   

-------------------------------------------------------------------------------

## PTE(page table entry)

![PTE](./pic/pte.png) 

* got first 10 bits from virtual address as the index, and the page tableptr in the processor register as base addr to got the PTE from the level 1 page table. 
* check the last P bit to make sure it is valid or make it valid by other 31 bits
* pick up last 12 bits and interpret it 
* pick first 20 bits as physical starting address for one page, which is level 2 page table , which is also a page in mem
* 

> page table ptr in the processor register should first 20 bits only  
> if the P is 0, then os always use the rest 31 bits to show where the page is on the disk  
  
**copy on write**

1. unix fork a new process, just copy the parent's page tables
2. mark PTE in both tabless as read-only
3. page fault on write creates one more pages 

**segment table is different from page table, because it has a limits, so one entry in the segment table will corresponds to a set of pte. which requires the ptes to be continues**

## X86 memory

![x86](./pic/x86 mem.png) 

**segments on top of 2 level paging** 

1. get segment selector from the instruction
2. use it in the global descriptor table to get the base and limit pair
3. the base points to address in the linear virtual address space, plus the offset, get the input for the multiple page table
4. look up page directory table and page table, plus the offset produces the physical address

**segments are used in legacy 16 ** 

_in 32 or 64 , segments are flattened . except the FS and GS segment registers_ 

> for each thread in the same process, gcc will generate thread local date storage using a segment descriptor FS.  
> when the thread is swapped in, the FS will tell you where the thread local storage data is  
> so FS in each thread is different  
> every thread has its own segment that is actually thread local storage





















